<?php

class TimberMenu extends TimberCore {

    public $MenuItemClass = 'TimberMenuItem';
    public $PostClass = 'TimberPost';

    public $items = null;
    public $id = null;
    public $ID = null;
    public $name = null;
    public $term_id;

    /**
     * @param int $slug
     */
    function __construct($slug = 0) {
        $locations = get_nav_menu_locations();
        if ($slug != 0 && is_numeric($slug)) {
            $menu_id = $slug;
        } else if (is_array($locations) && count($locations)) {
            $menu_id = $this->get_menu_id_from_locations($slug, $locations);
        } else if ($slug === false) {
            $menu_id = false;
        } else {
            $menu_id = $this->get_menu_id_from_terms($slug);
        }
        if ($menu_id) {
            $this->init($menu_id);
        } else {
            //TimberHelper::error_log("Sorry, the menu you were looking for wasn't found ('" . $slug . "'). Here's what Timber did find:");
        }
        return null;
    }

    /**
     * @param int $menu_id
     */
    private function init($menu_id) {
        $menu = wp_get_nav_menu_items($menu_id);
        if (is_array($menu)){
            $menu = self::order_children($menu);
        }
        $this->items = $menu;
        $menu_info = wp_get_nav_menu_object($menu_id);
        $this->import($menu_info);
        $this->ID = $this->term_id;
        $this->id = $this->term_id;
    }

    /**
     * @param string $slug
     * @param array $locations
     * @return mixed
     */
    private function get_menu_id_from_locations($slug, $locations) {
        if ($slug === 0) {
            $slug = $this->get_menu_id_from_terms($slug);
        }
        if (is_numeric($slug)) {
            $slug = array_search($slug, $locations);
        }
        if (isset($locations[$slug])) {
            return $locations[$slug];
        }
        return null;
    }

    /**
     * @param int $slug
     * @return int
     */
    private function get_menu_id_from_terms($slug = 0) {
        if (!is_numeric($slug) && is_string($slug)) {
            //we have a string so lets search for that
            $menu_id = get_term_by('slug', $slug, 'nav_menu');
            if ($menu_id) {
                return $menu_id;
            }
            $menu_id = get_term_by('name', $slug, 'nav_menu');
            if ($menu_id) {
                return $menu_id;
            }
        }
        $menus = get_terms('nav_menu', array('hide_empty' => true));
        if (is_array($menus) && count($menus)) {
            if (isset($menus[0]->term_id)) {
                return $menus[0]->term_id;
            }
        }
        return 0;
    }

    /**
     * @param array $menu_items
     * @param int $parent_id
     * @return TimberMenuItem|null
     */
    function find_parent_item_in_menu($menu_items, $parent_id) {
        foreach ($menu_items as &$item) {
            if ($item->ID == $parent_id) {
                return $item;
            }
        }
        return null;
    }

    /**
     * @param array $items
     * @return array
     */
    function order_children($items) {
        $index = array();
        $menu = array();
        foreach ($items as $item) {
            if(isset($item->ID)){
                if (is_object($item) && get_class($item) == 'WP_Post'){
                    $item = new $this->PostClass($item);
                }
                $index[$item->ID] = new $this->MenuItemClass($item);
            }
        }
        foreach ($index as $item) {
            if (isset($item->menu_item_parent) && $item->menu_item_parent && isset($index[$item->menu_item_parent])) {
                $index[$item->menu_item_parent]->add_child($item);
            } else {
                $menu[] = $item;
            }
        }
        return $menu;
    }

    /**
     * @return array
     */
    function get_items() {
        if (is_array($this->items)) {
            return $this->items;
        }
        return array();
    }
}


